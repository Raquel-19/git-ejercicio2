package com.example;

public enum EventType {

    TECH, MARKETING, BUSINESS
}
